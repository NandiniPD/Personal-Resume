let type=new Typed('#changing-text',{
    strings:['Nandini','a Btech student','Learner'],
    typeSpeed:50,
    backspeed:50,
    loop:true,
})